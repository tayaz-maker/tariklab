import { ALL_CLAIMS } from "../db/catalog.ts";
import { EDGES, NODES } from "../data.ts";
import { SAVE_KEY, SCHEMA_VERSION } from "../types.ts";
import type { Decision, Dossier, EndingId, GameState, Locale } from "../types.ts";
import { t } from "../i18n/copy.ts";

export function pushDecision(state: GameState, d: Omit<Decision, "turn">): GameState {
  return {
    ...state,
    decisions: [...state.decisions, { ...d, turn: state.turn }],
  };
}

function names(ids: string[]) {
  return ids.map((id) => NODES.find((n) => n.id === id)?.name ?? id);
}

function orderKey(state: GameState): "intact" | "legal" | "scatter" {
  if (state.stats.giz >= 28 && state.stats.saha >= 18) return "intact";
  if (state.stats.hukuk >= 50) return "legal";
  return "scatter";
}

function driftKeys(state: GameState): string[] {
  const keys: string[] = [];
  if (state.flags.leakSuppressed) keys.push("drift.tapes");
  if (hasSpend(state) && state.flags.erseverTalked) keys.push("drift.spent");
  if (state.flags.emniyetCooledUntil > 0) keys.push("drift.emniyet");
  if (state.investigation.stage === "dormant") keys.push("drift.sleep");
  if (state.flags.yesilUsed) keys.push("drift.yesil");
  return keys;
}

/** Derived from player-visible records only. Never infer a missing legacy
 * decision target from a current selection or an unrelated callback. */
export function researchHistory(state: GameState) {
  return ALL_CLAIMS.flatMap(claim => {
    const held = state.hand[claim.id];
    const compared = (state.investigation.comparisons ?? []).some(c => c.claimId === claim.id);
    const linked = (state.investigation.chain ?? []).some(c => c.claimId === claim.id &&
      state.investigation.documents.includes(c.documentId));
    const decisions = state.decisions.filter(d => d.target === claim.id);
    const tagged = (prefix: string) => state.tags.includes(`${prefix}:${claim.id}`);
    const retained = tagged("src-held"), shared = tagged("src-shared"), published = tagged("src-published");
    if ((!held || held.status === "UNKNOWN") && !compared && !linked && !decisions.length && !retained && !shared && !published) return [];
    return [{ claimId: claim.id, title: claim.title, layer: claim.layer,
      status: held?.status ?? "UNKNOWN", opened: Boolean(held && held.status !== "UNKNOWN"),
      compared, retained, shared, published, linked,
      openQuestion: Boolean(claim.contradiction) || !held || held.status !== "TRUE",
      decisions: decisions.map(d => ({ turn: d.turn, id: d.id, target: d.target })),
    }];
  });
}

function personalContradictions(state: GameState) {
  const ids = new Set(researchHistory(state).map(c => c.claimId));
  return ALL_CLAIMS.filter(c => ids.has(c.id) && c.contradiction)
    .map(c => `${c.title}: ${c.contradiction}`).slice(0, 8);
}

function researchSummary(state: GameState, locale: Locale) {
  const history = researchHistory(state);
  const worked = history.filter(c => c.compared || c.linked || c.decisions.length || c.published || c.shared || c.retained);
  if (!worked.length) return t(locale, "research.unworked");
  return t(locale, "research.summary", {
    opened: history.filter(c => c.opened).length,
    compared: history.filter(c => c.compared).length,
    published: history.filter(c => c.published).length,
    linked: history.filter(c => c.linked).length,
    questions: worked.filter(c => c.openQuestion).map(c => c.title).slice(-3).join(" / ") || t(locale, "end.none"),
  });
}

export function buildDossier(state: GameState): Dossier {
  const stanceProtect = Object.entries(state.stance).filter(([, v]) => v === "protect").map(([id]) => id);
  const memProtect = Object.entries(state.actorMemory).filter(([, tags]) => tags.includes("protected")).map(([id]) => id);
  const stanceSpend = Object.entries(state.stance).filter(([, v]) => v === "spend").map(([id]) => id);
  const memSpend = Object.entries(state.actorMemory).filter(([, tags]) => tags.includes("spent")).map(([id]) => id);
  const protectedActors = names([...new Set([...stanceProtect, ...memProtect])]);
  const sacrificedActors = names([...new Set([...stanceSpend, ...memSpend])]);
  const exposedDocuments = state.investigation.documents;
  const suppressedDocuments = state.investigation.suppressed;
  const risenFactions = Object.values(state.factions)
    .filter((f) => f.hostility >= 28 || f.resources >= 48)
    .map((f) => f.id);
  const brokenTies = Object.entries(state.edgeLive)
    .filter(([, e]) => e.trust < 20 || e.tension > 70)
    .map(([id]) => EDGES.find((e) => e.id === id)?.label ?? id);
  const publicKnowledge = Object.entries(state.factions.media?.knowledgeBase ?? {})
    .filter(([, k]) => k.status === "TRUE" || k.status === "PARTIAL")
    .map(([id]) => ALL_CLAIMS.find((c) => c.id === id)?.title ?? id);
  const contradictions = personalContradictions(state);
  const locale: Locale = "tr";
  const anchorDrift = driftKeys(state).map((k) => t(locale, k));
  const orderLeft = t(locale, `endOrder.${orderKey(state)}`);

  return {
    title: t(locale, "end.title"),
    protectedActors,
    sacrificedActors,
    exposedDocuments,
    suppressedDocuments,
    risenFactions,
    brokenTies,
    publicKnowledge,
    contradictions: contradictions.slice(0, 8),
    anchorDrift,
    orderLeft,
    causal: causalNarrative(state),
  };
}

export function displayDossier(state: GameState, locale: Locale) {
  const d = buildDossier(state);
  return {
    title: t(locale, "end.title"),
    protectedActors: d.protectedActors,
    sacrificedActors: d.sacrificedActors,
    exposedDocuments: d.exposedDocuments,
    suppressedDocuments: d.suppressedDocuments,
    risenFactions: d.risenFactions,
    brokenTies: d.brokenTies,
    publicKnowledge: d.publicKnowledge,
    contradictions: d.contradictions,
    anchorDrift: driftKeys(state).map((k) => t(locale, k)),
    orderLeft: t(locale, `endOrder.${orderKey(state)}`),
    causal: causalNarrative(state, locale),
  };
}

function hasSpend(state: GameState) {
  return Object.values(state.actorMemory).some((t) => t.includes("spent"));
}

export function buildRecap(state: GameState): string[] {
  const d = buildDossier(state);
  const lines: string[] = [d.title];
  lines.push(d.protectedActors.length ? `Korudukların: ${d.protectedActors.join(", ")}.` : "Kimseyi özellikle korumadın.");
  lines.push(d.sacrificedActors.length ? `Harcadıkların: ${d.sacrificedActors.join(", ")}.` : "Kimseyi açıkça harcamadın.");
  lines.push(d.exposedDocuments.length ? `Açığa çıkanlar: ${d.exposedDocuments.join(", ")}.` : "Açığa çıkan belge zinciri kısa.");
  lines.push(d.suppressedDocuments.length ? `Karanlıkta kalanlar: ${d.suppressedDocuments.join(", ")}.` : "Bastırılan özel bir dosya yok — ya açılmadı ya tutulamadı.");
  lines.push(d.risenFactions.length ? `Güçlenen kurumlar: ${d.risenFactions.join(", ")}.` : "Hiçbir taraf net yükselmedi.");
  lines.push(d.brokenTies.length ? `Dağılan ilişkiler: ${d.brokenTies.join(", ")}.` : "Bağlar kopmadı, inceldi.");
  lines.push(
    d.publicKnowledge.length
      ? `Kamuoyunun bildiği: ${d.publicKnowledge.join(", ")}.`
      : "Kamuoyu JİTEM’i teyit etmedi; söylenti veya sis.",
  );
  if (d.contradictions.length) lines.push(`Kaynakların çeliştiği noktalar: ${d.contradictions.slice(0, 3).join(" / ")}`);
  if (d.anchorDrift.length) lines.push(`Çıpalardan sapma: ${d.anchorDrift.join(" ")}`);
  lines.push(`Soruşturma: ${t("tr", `inv.${state.investigation.stage}`)}.`);
  lines.push(`Senin bıraktığın düzen: ${d.orderLeft}`);
  lines.push(
    `Gizlilik ${state.stats.giz} · Sadakat ${state.stats.sadakat} · Kamuoyu ${state.stats.kamuoyu} · Hukuk ${state.stats.hukuk}.`,
  );
  return lines;
}

export function replayFilename(seed: number) {
  return `DERIN-AG-1986-1996-${seed}.json`;
}

export function formatReplayJson(state: GameState) {
  const d = buildDossier(state);
  const frames = state.replayMeta.events.length ? state.replayMeta.events : state.replay;
  return {
    saveKey: SAVE_KEY,
    schemaVersion: SCHEMA_VERSION,
    seed: state.worldSeed,
    hat: state.hat,
    turn: state.turn,
    ending: state.ending,
    stats: state.stats,
    investigation: state.investigation,
    decisions: state.decisions,
    research: researchHistory(state),
    events: frames.map((f) => ({
      turn: f.turn,
      familyId: f.familyId ?? null,
      variantId: f.variantId ?? null,
      note: f.note,
      factionActs: f.factionActs,
    })),
    factionActions: Object.values(state.factions).map((f) => ({
      id: f.id,
      lastAct: f.lastAct,
      memory: f.memory.slice(-4),
    })),
    major: state.replayMeta.major,
    dossier: d,
  };
}

export function formatReplay(state: GameState): string {
  const json = formatReplayJson(state);
  const d = json.dossier;
  const lines: string[] = [
    "DERİN AĞ — SENİN 1986–1996 HİKÂYEN",
    `${SAVE_KEY} · schema ${SCHEMA_VERSION}`,
    `tohum ${state.worldSeed} · hat ${state.hat} · tur ${state.turn} · sonuç ${state.ending ?? "—"}`,
    "",
    ...buildRecap({ ...state, dossier: d }),
    "",
    "KARARLAR",
  ];
  for (const dec of state.decisions) {
    lines.push(`t${dec.turn} ${dec.kind} ${dec.id}${dec.target ? ` @${dec.target}` : ""} — ${dec.summary}`);
  }
  if (!state.decisions.length) lines.push("(kayıt yok)");
  lines.push("", "OLAYLAR");
  for (const f of json.events) {
    if (!f.familyId && !f.note) continue;
    lines.push(`t${f.turn} ${f.familyId ?? "—"}/${f.variantId ?? "—"} ${f.note}`);
  }
  lines.push("", "FACTION");
  for (const f of json.factionActions) {
    lines.push(`${f.id}: son ${f.lastAct || "—"} · bellek ${f.memory.join(",") || "—"}`);
  }
  return lines.join("\n");
}

export function causalNarrative(state: GameState, locale: Locale = "tr"): string[] {
  const spentN = Object.values(state.stance).filter((v) => v === "spend").length;
  const denies = state.decisions.filter((d) => d.id === "inkar_yaz" || d.id === "sizinti_bastir" || d.id === "e6-bas" || d.id === "e10-inkar").length;
  const opens = state.decisions.filter((d) => d.id === "rapor_yaz" || d.id === "soru_ac" || d.id === "bag_ifsa" || d.id === "e6-not").length;
  const en = locale === "en";
  const lines: string[] = [];
  if (state.ending === "kontrollu_parcalanma" || state.ending === "inkar_ayakta") {
    lines.push(
      en
        ? "The network did not fully come apart at the recorded outcome."
        : "Sonuç kaydında ağ tamamen çözülmedi.",
    );
    if (state.investigation.documents.length === 0 || state.investigation.suppressed.length) {
      lines.push(
        en
          ? "Some records remain missing or suppressed in the file."
          : "Dosyada eksik veya bastırılmış kayıtlar var.",
      );
    }
  } else if (state.ending === "giz_coktu" || state.ending === "susurluk_patlama") {
    lines.push(
      opens >= 2
        ? en
          ? "Your reports, exposure or inquiry-opening decisions left a record. Secrecy broke at the outcome."
          : "Rapor, ifşa veya soruşturmayı açma kararların iz bıraktı. Finalde gizlilik kırıldı."
        : en
          ? "Secrecy broke at the recorded outcome."
          : "Sonuç kaydında gizlilik kırıldı.",
    );
  } else if (state.ending === "ersever_esigi") {
    lines.push(
      en
        ? "The insider-talk threshold was reached in this game."
        : "Oyunda içeriden konuşma eşiği aşıldı.",
    );
  } else if (state.ending === "kismi_adalet") {
    lines.push(
      en
        ? "The legal and public conditions met the partial-justice threshold; the order-gap remains unresolved."
        : "Hukuk ve kamuoyu koşulları kısmi adalet eşiğini karşıladı; emir boşluğu çözülmüş sayılmaz.",
    );
    const chainN = state.investigation.chain?.length ?? 0;
    const cmpN = state.investigation.comparisons?.length ?? 0;
    if (chainN >= 2) {
      lines.push(
        en
          ? "Claim-bound evidence links remain in the file; the source of the order remains open."
          : "Dosyada iddiaya bağlı delil halkaları var; emrin kaynağı açık kaldı.",
      );
    }
    if (cmpN >= 1) {
      lines.push(
        en
          ? "Your claim-bound source comparisons remain in the file."
          : "İddiaya bağlı kaynak karşılaştırmaların dosyada duruyor.",
      );
    }
  } else if (spentN >= 2) {
    lines.push(
      en
        ? "Your recorded stances include spending more than one person."
        : "Kayıtlı duruşlarında birden fazla kişiyi harcama izi var.",
    );
  }
  const namedProtect = names(
    Object.entries(state.actorMemory)
      .filter(([, tags]) => tags.includes("protected"))
      .map(([id]) => id),
  );
  const namedSpent = names(
    Object.entries(state.actorMemory)
      .filter(([, tags]) => tags.includes("spent") || tags.includes("promise-broken"))
      .map(([id]) => id),
  );
  const protectionRecords = state.decisions.flatMap((d) => {
    if (!d.target || !Number.isInteger(d.turn) || d.turn < 1 || d.turn > state.turn) return [];
    const target = d.kind === "stance" && d.id === "protect"
      ? NODES.find((n) => n.id === d.target)?.name
      : d.kind === "action" && d.id === "bag_koru"
        ? EDGES.find((e) => e.id === d.target)?.label
        : undefined;
    return target ? [`${target} (T${d.turn})`] : [];
  });
  if (protectionRecords.length) {
    const records = [...new Set(protectionRecords)].slice(-3).join("; ");
    lines.push(en ? `Recorded protection decisions: ${records}.` : `Kayıtlı koruma kararların: ${records}.`);
  } else if (namedProtect.length) {
    lines.push(
      en
        ? `Protection traces in memory: ${namedProtect.join(", ")}.`
        : `Koruma izi taşıyanlar: ${namedProtect.join(", ")}.`,
    );
  }
  if (namedSpent.length) {
    lines.push(
      en
        ? `Spending or broken-word traces in memory: ${namedSpent.join(", ")}.`
        : `Harcama veya bozulan söz izi taşıyanlar: ${namedSpent.join(", ")}.`,
    );
  }
  if (!lines.length) {
    lines.push(
      en
        ? "Partial interest-networks walked on what they themselves knew. There was no single hand."
        : "Parçalı çıkar ağları kendi bildikleriyle yürüdü. Tek el yoktu.",
    );
  }
  // These are recorded decisions and final values, not an inferred trend or
  // a claim that one action caused the ending. Legacy targetless rows remain
  // usable for counts, but never acquire an invented target or decision date.
  if (denies > 0) lines.push(en ? "Your record includes denial or suppression decisions." : "Kayıtlarında inkâr veya bastırma kararların var.");
  lines.push(en
    ? `Last record: secrecy ${state.stats.giz}, public pressure ${state.stats.kamuoyu}, legal pressure ${state.stats.hukuk}.`
    : `Son kayıtta gizlilik ${state.stats.giz}, kamuoyu baskısı ${state.stats.kamuoyu}, hukuk baskısı ${state.stats.hukuk}.`);
  lines.push(researchSummary(state, locale));
  return lines;
}

export function pickEnding(state: GameState): EndingId | null {
  if (
    state.flags.erseverTalked &&
    state.turn === 6 &&
    state.stats.giz < 14 &&
    !state.flags.leakSuppressed &&
    state.stats.sadakat < 28
  ) {
    return "ersever_esigi";
  }
  if (state.flags.commandShifted && state.stats.saha < 12 && state.stats.etki < 12 && state.turn >= 5) {
    return "komuta_felaketi";
  }
  if (state.flags.gizCrisisTurns >= 4 && state.stats.hukuk >= 62 && state.stats.giz < 4 && state.turn >= 9) {
    return "giz_coktu";
  }
  if (state.stats.sadakat < 10 && state.stats.saha >= 45 && state.turn >= 8) {
    return "saha_felaketi";
  }
  if (state.turn < 10) return null;

  const inv = state.investigation.stage;
  const protectedN = Object.values(state.stance).filter((v) => v === "protect").length;
  const spentN = Object.values(state.stance).filter((v) => v === "spend").length;
  if (inv === "public" || inv === "response") {
    if (state.stats.hukuk >= 55 && state.stats.kamuoyu >= 42) return "kismi_adalet";
    if ((state.investigation.chain?.length ?? 0) >= 2 && state.stats.hukuk >= 48 && state.stats.kamuoyu >= 32) return "kismi_adalet";
  }
  if (state.stats.etki < 16 && state.stats.kara >= 38 && state.stats.saha < 20) return "rakip_zafer";
  if (state.stats.saha < 14 && state.stats.etki >= 32 && state.stats.giz >= 22) return "kurumsal_tasfiye";
  if (state.stats.giz >= 30 && state.stats.saha >= 18 && state.stats.etki >= 16 && spentN < 3) return "inkar_ayakta";
  if (state.stats.giz >= 18 && protectedN >= 1) return "kontrollu_parcalanma";
  if (state.stats.giz >= 18) return "kontrollu_parcalanma";
  return "susurluk_patlama";
}
