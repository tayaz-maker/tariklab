import { EDGES, NODES } from "../data.ts";
import type { EdgeLive, GameState, Locale } from "../types.ts";
import { t } from "../i18n/copy.ts";

export function seedEdgeLive(): Record<string, EdgeLive> {
  const out: Record<string, EdgeLive> = {};
  for (const e of EDGES) {
    if (e.evidence === "BELGELİ") out[e.id] = { trust: 70, dependency: 50, secrecy: 25, tension: 20 };
    else if (e.evidence === "GÜÇLÜ") out[e.id] = { trust: 52, dependency: 40, secrecy: 48, tension: 28 };
    else if (e.evidence === "TARTIŞMALI") out[e.id] = { trust: 28, dependency: 22, secrecy: 62, tension: 44 };
    else out[e.id] = { trust: 10, dependency: 8, secrecy: 80, tension: 12 };
  }
  return out;
}

function clamp(n: number) {
  return Math.max(0, Math.min(100, Math.round(n)));
}

export function touchEdge(state: GameState, id: string, delta: Partial<EdgeLive>): GameState {
  const cur = state.edgeLive[id] ?? { trust: 40, dependency: 30, secrecy: 50, tension: 30 };
  const next: EdgeLive = {
    trust: clamp(cur.trust + (delta.trust ?? 0)),
    dependency: clamp(cur.dependency + (delta.dependency ?? 0)),
    secrecy: clamp(cur.secrecy + (delta.secrecy ?? 0)),
    tension: clamp(cur.tension + (delta.tension ?? 0)),
  };
  return { ...state, edgeLive: { ...state.edgeLive, [id]: next } };
}

export type EdgeMove = "strengthen" | "weaken" | "observe" | "mediate" | "isolate" | "expose" | "protect";

export function edgePreview(kind: EdgeMove) {
  switch (kind) {
    case "strengthen":
      return "Güven ve bağımlılık artar. Sızıntı yüzeyi büyür.";
    case "weaken":
      return "Mesafe. Kişi bağımsızlaşabilir, gizlilik toparlar.";
    case "observe":
      return "Bağı değiştirmez. Kısmi bilgi. İz bırakır.";
    case "mediate":
      return "Gerilim düşer. Güven toparlar. İz bırakır.";
    case "isolate":
      return "Sekiz duvar. Gizlilik artar, kapasite düşer.";
    case "expose":
      return "Kamu ve hukuk ısınır. Giz yanar. BELGELİ kilit durmaz.";
    case "protect":
      return "Bağın sızıntı yüzeyi kapanır. Kapasite bağlanır.";
  }
}

export function liveLine(e: EdgeLive, locale: Locale = "tr") {
  return t(locale, "map.live", { trust: e.trust, dep: e.dependency, secrecy: e.secrecy, tension: e.tension });
}

export type EdgeSignal = "stable" | "pressure" | "fragile" | "hot" | "sealed";

export function edgeSignal(live: EdgeLive): EdgeSignal {
  if (live.secrecy >= 70 && live.trust >= 48) return "sealed";
  if (live.tension >= 62 || live.secrecy < 22) return "hot";
  if (live.trust < 28 || live.dependency < 16) return "fragile";
  if (live.tension >= 44 || live.secrecy < 36) return "pressure";
  return "stable";
}

export function propagationRisk(state: GameState, edgeId: string) {
  const def = EDGES.find((e) => e.id === edgeId);
  const live = state.edgeLive[edgeId];
  if (!def || !live) return 0;
  const heat = (state.nodeHeat[def.from] ?? 0) + (state.nodeHeat[def.to] ?? 0);
  const sig = edgeSignal(live);
  const bonus = sig === "hot" ? 18 : sig === "pressure" ? 10 : sig === "fragile" ? 8 : sig === "sealed" ? -12 : 0;
  return clamp(live.tension * 0.4 + (100 - live.secrecy) * 0.32 + heat * 9 + bonus);
}

export function edgeForecast(state: GameState, edgeId: string, locale: Locale = "tr") {
  const live = state.edgeLive[edgeId];
  if (!live) return t(locale, "map.forecast.quiet");
  const risk = propagationRisk(state, edgeId);
  const sig = edgeSignal(live);
  if (sig === "fragile" || live.trust < 22) return t(locale, "map.forecast.break");
  if (risk >= 58 || sig === "hot") return t(locale, "map.forecast.heat");
  if (risk >= 38 || sig === "pressure") return t(locale, "map.forecast.leak");
  return t(locale, "map.forecast.quiet");
}

export function dangerousActors(state: GameState): string[] {
  const out = new Set<string>();
  for (const n of NODES) {
    const heat = state.nodeHeat[n.id] ?? 0;
    const tags = state.actorMemory[n.id] ?? [];
    const spent = tags.includes("spent") || tags.includes("leaked") || tags.includes("promise-broken");
    if (heat >= 2 || spent) out.add(n.id);
  }
  for (const e of EDGES) {
    const live = state.edgeLive[e.id];
    if (!live) continue;
    const sig = edgeSignal(live);
    if (sig === "hot" || (sig === "fragile" && live.tension >= 50)) {
      out.add(e.from);
      out.add(e.to);
    }
  }
  return [...out];
}

export function edgeMarks(state: GameState, edgeId: string): Array<"P" | "F" | "L"> {
  const live = state.edgeLive[edgeId];
  if (!live) return [];
  const sig = edgeSignal(live);
  const marks: Array<"P" | "F" | "L"> = [];
  if (sig === "pressure" || sig === "hot") marks.push("P");
  if (sig === "fragile") marks.push("F");
  if (propagationRisk(state, edgeId) >= 48) marks.push("L");
  return marks;
}
