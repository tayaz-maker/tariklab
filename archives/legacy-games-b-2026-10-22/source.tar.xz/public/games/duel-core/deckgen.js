import { pick, random, shuffle } from "./random.js";
import { copyKey } from "./card-data.js";

export function generateDeck(pool, seed) {
  const rng = { rng: seed >>> 0 },
    main = [],
    copies = new Map(),
    bosses = new Set();
  // A seeded pair of family lines gives targeted expansion tools real partners.
  // Existing saved decks never pass through this generator.
  const series = [...new Set(pool.filter((c) => c.kind === "unit").flatMap((c) => c.series || []))];
  const focus = new Set(shuffle(series, rng).slice(0, 2));
  let middle = 0;
  // 23 + 11 + 6 is inside every requested distribution interval.
  for (const [kind, count] of [
    ["unit", 23],
    ["spell", 11],
    ["trap", 6],
  ]) {
    for (let i = 0; i < count; i++) {
      const eligible = pool.filter(
        (c) =>
          c.kind === kind &&
          c.deckLocation === "main" &&
          (copies.get(copyKey(c)) || 0) < 3 &&
          !(c.level >= 5 && c.level <= 6 && middle >= 6) &&
          !(c.level >= 7 && bosses.size >= 2 && !bosses.has(copyKey(c))),
      );
      if (!eligible.length) throw new Error(`Insufficient legal ${kind} pool`);
      const weighted = eligible.flatMap((c) =>
        Array(
          (c.kind === "unit" && c.level <= 4 ? 6 : c.level <= 6 ? 2 : 1) *
            (c.series?.some((s) => focus.has(s)) ? 8 : 1),
        ).fill(c),
      );
      const card = pick(weighted, rng);
      main.push(card.id);
      copies.set(copyKey(card), (copies.get(copyKey(card)) || 0) + 1);
      if (card.level >= 5 && card.level <= 6) middle++;
      if (card.level >= 7) bosses.add(copyKey(card));
    }
  }
  const auxiliary = shuffle(
    pool.filter((c) => c.deckLocation === "auxiliary"),
    rng,
  )
    .slice(0, Math.floor(random(rng) * 6))
    .map((c) => c.id);
  let deck = shuffle(main, rng);
  const byId = new Map(pool.map((c) => [c.id, c]));
  const openingUnits = deck.slice(0, 5).filter((id) => byId.get(id).kind === "unit").length;
  const mulligan = openingUnits === 0 || openingUnits === 5;
  if (mulligan) deck = shuffle(deck, rng);
  return { main: deck, auxiliary, seed: seed >>> 0, rng: rng.rng, mulligan };
}

export function validateDeck(deck, pool) {
  const byId = new Map(pool.map((c) => [c.id, c]));
  if (
    !deck ||
    deck.main?.length !== 40 ||
    !Array.isArray(deck.auxiliary) ||
    deck.auxiliary.length > 5
  )
    return false;
  const copies = new Map(),
    counts = { unit: 0, spell: 0, trap: 0 },
    bosses = new Set();
  let middle = 0;
  for (const id of deck.main) {
    const card = byId.get(id);
    if (!card || card.deckLocation !== "main") return false;
    copies.set(copyKey(card), (copies.get(copyKey(card)) || 0) + 1);
    if (copies.get(copyKey(card)) > 3) return false;
    counts[card.kind]++;
    if (card.level >= 5 && card.level <= 6) middle++;
    if (card.level >= 7) bosses.add(copyKey(card));
  }
  return (
    counts.unit >= 22 &&
    counts.unit <= 24 &&
    counts.spell >= 10 &&
    counts.spell <= 12 &&
    counts.trap >= 6 &&
    counts.trap <= 8 &&
    middle <= 6 &&
    bosses.size <= 2 &&
    deck.auxiliary.every((id) => byId.get(id)?.deckLocation === "auxiliary")
  );
}
