/**
 * Per-theme presentation and isolation. Engine rules stay shared.
 * Unknown themes keep the historical GETT-OH! fallback so VETO/GETT
 * binaries that treated "not veto-h" as GETT do not change.
 */
import { resolveCardArt } from "./art-release.js";

export const SIBLING_THEMES = ["veto-h", "gett-oh"];
export const LEGACY_SHARED_THEMES = ["veto-h", "gett-oh"];

const VETO_LABELS = {
  tr: {
    unit: "Kadro",
    spell: "Kampanya",
    trap: "Skandal",
    battle: "Tartışma",
    auxiliary: "Koalisyon Destesi",
    grave: "Atılan Kartlar",
    "end-main": "Turu Bitir",
    "set-field": "Alanı Set Et",
  },
  en: {
    unit: "Campaigner",
    spell: "Campaign",
    trap: "Scandal",
    battle: "Debate",
    auxiliary: "Coalition",
    "end-main": "End Turn",
    "set-field": "Set Field",
  },
};

const GETT_LABELS = {
  tr: {
    unit: "Adam",
    spell: "Racon",
    trap: "İhbar",
    battle: "Kapışma",
    auxiliary: "Birleşik Deste",
    grave: "Iskarta",
    "end-main": "Turu Bitir",
    "set-field": "Alanı Set Et",
  },
  en: {
    unit: "Crew",
    spell: "Racon",
    trap: "Tip-off",
    battle: "Clash",
    auxiliary: "Alliance",
    "end-main": "End Turn",
    "set-field": "Set Field",
  },
};

// The match rail's two theme-bound nouns. VETO-H! and GETT-OH! are frozen, so
// both keep the wording their players already see; only a theme that declares
// its own overrides it.
const FLOW_COPY_DEFAULT = {
  graveTo: { tr: "Atılan Kartlar’a", en: "the graveyard" },
  tribute: { tr: "adak", en: "a tribute" },
};

export const THEME_META = {
  "veto-h": {
    name: "VETO-H!",
    point: "OP",
    pointLong: { tr: "Oy Puanı", en: "Vote Points" },
    identityKey: "campaignStyle",
    defaultIdentity: "halkci",
    prefix: "SND",
    trapSeries: "Skandal",
    fileLabelKey: "campaignFile",
    starLabelKey: "matchStar",
    turnLabelKey: "turningPoint",
    resultLabelKey: "electionResult",
    workLabelKey: "matchStar",
    showElectionShare: true,
    showHardestWorker: false,
    hoodAccent: false,
    art: { kind: "webp", width: 576, height: 384 },
    eyebrow: { tr: "SEÇİM GECESİ · KART DÜELLOSU", en: "ELECTION NIGHT · CARD DUEL" },
    labels: VETO_LABELS,
    deckHeading: { tr: "Kampanya Destesi", en: "Campaign Deck" },
    deckIntro: {
      tr: "Burada oynayacağın 40 kartlık desteyi seçiyorsun. Her seçenek farklı bir kart listesidir.",
      en: "You are choosing the 40-card deck you will play. Each option is a different card list.",
    },
    battleEnter: { tr: "Tartışmaya Geç", en: "Enter Debate" },
    battleEnd: { tr: "Tartışmayı Bitir", en: "End Debate" },
    tributeSummon: { tr: "İstifa ile Çağır", en: "Summon by Resignation" },
    normalSummon: { tr: "Normal Çağır", en: "Normal Summon" },
    setVerb: { tr: "Set Et", en: "Set" },
    directAttack: { tr: "Açık Miting", en: "Open Rally" },
    unitAttack: { tr: "Tartış", en: "Debate" },
    activateTrap: { tr: "Skandalı Aç", en: "Reveal Scandal" },
    activateSpell: { tr: "Kampanyayı Aç", en: "Launch Campaign" },
    recordFile: { tr: "Kampanya dosyası", en: "Campaign File" },
    flowCopy: FLOW_COPY_DEFAULT,
  },
  "gett-oh": {
    name: "GETT-OH!",
    point: "RP",
    pointLong: { tr: "Racon Puanı", en: "Racon Points" },
    identityKey: "neighborhood",
    defaultIdentity: "kadikoy",
    prefix: "RCN",
    trapSeries: "İhbar",
    fileLabelKey: "nightFile",
    starLabelKey: "nightMove",
    turnLabelKey: "tableTurn",
    resultLabelKey: "postMatch",
    workLabelKey: "hardestWorker",
    showElectionShare: false,
    showHardestWorker: true,
    hoodAccent: true,
    art: { kind: "webp", width: 400, height: 300 },
    eyebrow: { tr: "İSTANBUL GECESİ · KART DÜELLOSU", en: "ISTANBUL NIGHT · CARD DUEL" },
    labels: GETT_LABELS,
    deckHeading: { tr: "Racon Destesi", en: "Racon Deck" },
    deckIntro: {
      tr: "Burada oynayacağın 40 kartlık desteyi seçiyorsun. Her semt farklı bir kart listesidir.",
      en: "You are choosing the 40-card deck you will play. Each option is a different card list.",
    },
    battleEnter: { tr: "Kapışmaya Geç", en: "Enter Clash" },
    battleEnd: { tr: "Kapışmayı Bitir", en: "End Clash" },
    tributeSummon: { tr: "Adam Yakarak Sür", en: "Tribute Crew" },
    normalSummon: { tr: "Sahaya Sür", en: "Deploy Crew" },
    setVerb: { tr: "Setle", en: "Set" },
    directAttack: { tr: "Kapıya Dayan", en: "Storm the Door" },
    unitAttack: { tr: "Kapış", en: "Clash" },
    activateTrap: { tr: "İhbarı Aç", en: "Reveal Tip-off" },
    activateSpell: { tr: "Raconu Aç", en: "Play Racon" },
    recordFile: { tr: "Gece dosyası", en: "Night File" },
    flowCopy: FLOW_COPY_DEFAULT,
  },
};

export function themeMeta(theme) {
  return THEME_META[theme] || THEME_META["gett-oh"];
}

export function identityValue(theme, settings = {}) {
  const meta = themeMeta(theme);
  return settings[meta.identityKey] || meta.defaultIdentity;
}

export function identityPatch(theme, deckId, extra = {}) {
  return { [themeMeta(theme).identityKey]: deckId, ...extra };
}

export function cardArt(theme, card) {
  return resolveCardArt(theme, card, themeMeta(theme).art);
}

export function pickLang(value, lang) {
  if (!value || typeof value === "string") return value || "";
  return lang === "en" ? value.en || value.tr : value.tr || value.en;
}

/** The rail's theme-bound nouns, with the frozen siblings' wording as default. */
export function flowWords(theme, lang) {
  const flow = themeMeta(theme).flowCopy || FLOW_COPY_DEFAULT;
  const pick = (v) => (lang === "en" ? v.en : v.tr);
  return { graveTo: pick(flow.graveTo), tribute: pick(flow.tribute) };
}
