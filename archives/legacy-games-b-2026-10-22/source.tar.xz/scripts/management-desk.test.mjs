import { frozenNextWaveBytes } from "./scoped-engine-provenance.mjs";
import test from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { JOBS } from "../public/games/tc-sim/js/catalog.js";
import { EDUCATION_PATHS } from "../public/games/tc-sim/js/education.js";
import { NETWORK_CAST } from "../public/games/tc-sim/js/network.js";
import { MARKET } from "../public/games/tc-sim/js/wealth.js";
import { POLICIES, EVENTS, REGIONS, FOREIGN_AXES } from "../public/games/next-wave/devlet-data.js";
import { deskEnglish } from "../public/games/tc-sim/js/desk.js";

// Donmuş taban: içerik/simülasyon kaynakları yalnız bilinçli bir ürün kararıyla
// değişir. Taban en son "Nasıl Oynanır" kapanışında yenilendi: paylaşılan
// runtime'a yapılandırılmış yardım bölümleri (helpSections/helpPanel) eklendi ve
// DEVLET'in tek paragraflık yardımı bu bölümlere taşındı. 2026-09-14'te onaylı
// ilk depth dalgası yalnız next-wave.js içindeki Apartman state/simülasyonunu
// değiştirdi. 2026-09-15 Wave 2, aynı dosyadaki Son 100 Gün save doğrulaması ve
// v2 başlangıç state'ini bilinçli olarak değiştirdi; TC SIM ve DEVLET kaynakları
// bu turda hâlâ donmuş durumda. 2026-09-15 Wave 3 yalnız aynı orkestratördeki
// Kayıp Telefon state/action yönlendirmesini V2 deduction modülüne taşıdı;
// TC SIM ve DEVLET davranışı değişmedi. 2026-09-15 Wave 4, yalnız TC SIM'e
// sürümlü life-depth state'i, nedensel arklar ve Hayat Dosyası ekledi.
// 2026-09-16 Wave 4 content-max, life-content.js kataloğunu ve events/time
// kancalarını ekledi; engine math, save v6 ve DEVLET kaynakları donmuş kaldı.
// 2026-09-16 Wave 4 kapanış denetimi life-content.js içinde iki hedefli düzeltme
// yaptı: ölü/ayrılmış aktör kapısı ve Hayat Dosyası iz önceliği.
// 2026-09-17 kapanış entegrasyonu yalnız bağlama duyarlı partner/iş/konut
// callback'lerine due-time revalidation ekledi; frozen ekonomi ve yaşam matematiği değişmedi.
// 2026-09-17 late-life mini patch yalnız life-content.js kataloğuna 65+ authored
// düğüm, zincir, gecikmeli geri dönüş ve dosya izi ekledi; motor matematiği değişmedi.
// Wave 5 yalnız TC SIM: DEVLET'in ayrı causal foundation katmanını ve mevcut
// DEVLET kernel entegrasyonunu değiştirir; TC SIM yaşam matematiğine dokunmaz.
// Wave 5 final core entegrasyonu DEVLET'te entropy recovery, weighted crisis
// selection ve karar kapasitesi açıklamasını bilinçli olarak güncelledi.
// Wave 5 content-max, TC SIM: DEVLET'e devlet-content.js kataloğunu ve
// next-wave.js / devlet-sim.js / presentation.js kancalarını ekler; fiscal
// causality, entropy recovery, crisis/form math, save V2 ve 2002 POLICIES/EVENTS
// sayıları donmuş kalır. Overlay kadrolar flavor-only; içerik seçimi 2 politika
// kotasını tüketmez.
// Refresh the frozen TC SIM baseline for this authorized historical-start core;
// unrelated content and DEVLET assets remain guarded by the same digest.
// 2026-10-07 authorized body presentation adds body-visual.js only; existing engines remain byte-identical.
// 2026-10-07 authorized exchange/business extension adds exchange.js and updates wealth/bank-business.
test("frozen baseline: historical-start-agnostic content and simulation sources stay unchanged", () => {
  const files = readdirSync("public/games/tc-sim/js")
    .filter(f => f.endsWith(".js") && !["app.js", "desk.js", "historical-scenarios.js"].includes(f))
    .map(f => `public/games/tc-sim/js/${f}`)
    .concat(["public/games/next-wave.js", "public/games/next-wave/devlet-data.js", "public/games/next-wave/devlet-sim.js", "public/games/next-wave/shared/runtime.js", "public/games/tc-sim-devlet/presentation.js"]).sort();
  // Authorized life/era expansion adds bank-business, intimacy, and
  // period-economy. Keep the full file inventory and content pinned so later
  // changes still need a conscious product decision.
  // 2026-10-07 authorized historical economy/date wave adds game-date.js,
  // dated wage budgets and five period market entries; unrelated files stay pinned.
  // Authorized marriage wave: wedding-planning helper + existing household/social/parenting integration.
  // Authorized city wave integrates one geography helper into existing life engines.
  // Authorized language wave adds a read-only presentation helper; engines unchanged.
  // Authorized Package 2: life.js pauses detained job load, commute and experience only.
  // Package 2 combined: occupational exposure also excludes detained work.
  // Combined #189: weekly career actions also honor existing detention.
  // Authorized Package 2: bounded work recovery uses existing body/life/time/state only.
  // Authorized Package 3: existing partial friend loans join debt-memory follow-up.
  assert.equal(files.length, 74);
  const hash = createHash("sha256");
  for (const file of files) hash.update(file).update(file === "public/games/next-wave.js" ? frozenNextWaveBytes(readFileSync(file)) : readFileSync(file));
  // Re-pinned for the DEVLET maps PR: next-wave.js (geo dispatch + month
  // tick), devlet-sim.js (beginDecisionMonth extracted, behaviour unchanged)
  // and presentation.js (regions/foreign screens render the maps).
  // Re-pinned again so those map records stay in the open desk list instead
  // of a closed <details> table the operations desk cannot click.
  // Re-pinned for the TC SIM decision network: new decision-network.js (38th
  // source) and time.js calling its week close after the parenthood week.
  // Re-pinned again for Polish readers: runtime.js, help.js and wealth.js pick
  // the content language with PL -> EN fallback instead of showing Turkish.
  // Re-pinned for Kapı Nöbeti: next-wave.js public title only. The slug,
  // save version and simulation stay the previous baseline.
  // 2026-09-30: authorized shared save-panel DOM positioning only.
  // Slot writes, overwrite confirmation, engine/content and schemas unchanged.
  // 2026-10-06: authorized TC SIM life/era content and simulation expansion.
  // Authorized balance pass: business owner turnover/time, move time, debt overflow preservation.
  // Wave C re-pin: display labels only (help, life reasons, lifetime lifestyle, wealth names).
  // Ids, prices, SAVE_VERSION and simulation stay the previous baseline.
  // Wave C onto main: shelf categories follow the new names; Emlak view stays.
  // Semt: quarters.js adds three-neighborhood housing and corner shops. Save stays v6.
  // Pocket: pocket-income.js adds small weekly notices. life/time/save call it. Save stays v6.
  // March rent + Hatır: march-hatir.js steps neighborhood rent and three yearly weeks. Save stays v6.
  // Partner month + workplace notes: partner-workplace.js. Save stays v6.
  // Risk layer: risk-layer.js adds short +18 costs, dosya, and detention. Save stays v6.
  // Both layers together: partner-workplace.js and risk-layer.js. Save stays v6.
  // Askerlik window: askerlik.js, one 18–25 interruption. Save stays v6.
  // Icra/haciz: icra.js. Save stays v6.
  // Maps, everyday Turkish, and kumar odds. Save stays v6. Rent logic unchanged.
  // Kaynaklar: help.js adds the sources section. Save stays v6.
  // Girisim: quarters.js multiple stalls, inspection file, separate weeks. Save stays v6.
  // Tezgah ince: close/sell labels, single-stall inspection, army drop, twin cut, kalfa, icra skim. Save stays v6.
  // Combined bank-record/month-cash foundation preserves D0 debt and housing.
  // Approved layout-only Bankalar: navigation/help/new presentation source; engines unchanged.
  // Approved mortgage contract + wealth/month-close/credit-budget/debt-pressure hooks.
  // Approved read-only bank-record underwriting gates in bank-business and wealth.
  // Approved icra review lifecycle and suspended stall collection; inventory unchanged.
  // Approved prospective social-insurance source + state normalization/weekly-life hooks.
  // Approved secured mortgage claim/settlement hooks in mortgage, wealth and icra; same inventory.
  // Approved optional wage collection in icra and actual salary posting in time; inventory unchanged.
  // Approved bounded compulsory private-sector wage collection hook in icra.
  // Approved source-linked fine finality and bounded evidence/counsel/review hooks in icra.
  // Combined approved court/wage source with prospective service-day/pension hooks.
  // Approved Package 3: bounded repeat-sentence custody reuses work/service gates and defers unstarted jobs.
  // Approved Package 3: source-linked verdicts, liveness, promises and bounded disengagement together.
  // Approved Package 4: observed work fuel replaces the existing variable car budget; no public fare twice.
  // Combined with #198: final-custody stall predicate remains protected.
  // Combined insurance allocation remains inside the same vehicle budget.
  // Combined Package 4 district visibility; retain observed fuel, insurance and custody sources.
  // Wave1 decision repair: approved zero-safe DEVLET treasury, terminal guards,
  // focused Apartman repair target and once-only follow-up settlement. No new
  // coefficients/content/schema. 159 focused tests and 42 source +42 built
  // Chromium cases cover the reviewed behavior; every other source stays pinned.
  // TC SIM 2.0 A+B+C: authorized UI preferences/status, banking/receipts, regions and maps.
  // Unrelated content stays pinned.
  // Authorized reference UI: shared shell/status/map presentation and static ui-icons.js.
  // Authorized menu ownership: navigation/shell/drafts and quarters render-only projection.
  // tc-sim-menu.test.mjs separately pins all engine bytes (quarters before its UI renderer).
  // Authorized Phase 0 gameplay package; all unrelated files retain their bytes.
  // Astra TC-2: authorized final-dossier read model and terminal snapshot handoff only.
  // Astra TC-1: compose the child-care payoff with the accepted TC-2 sources.
  assert.equal(hash.digest("hex"), "e73b39d6afeb31b65b583ad96522e3b9cc6965ea8e6502d531c9623d48e3921b");
});
test("accepted content counts remain intact", () => {
  assert.equal(JOBS.length, 58);
  assert.equal(EDUCATION_PATHS.length, 18);
  assert.equal(NETWORK_CAST.length, 41); // 40 + kardeş
  assert.equal(Object.keys(MARKET).length, 62);
  assert.equal(POLICIES["2002"].length, 48);
  assert.equal(EVENTS["2002"].length, 62);
  assert.equal(REGIONS.length, 7);
  assert.equal(FOREIGN_AXES.length, 8);
});
test("desk boundary cannot dispatch actions, read hidden state or persist UI", () => {
  for (const file of ["public/games/shared/management-desk.js", "public/games/tc-sim/js/desk.js", "public/games/tc-sim-devlet/desk.js"]) {
    const source = readFileSync(file, "utf8");
    assert.doesNotMatch(source, /localStorage|sessionStorage|\.actual\b|session\.act|\.setUI\(|JSON\.stringify|\.click\(/);
  }
  const app = readFileSync("public/games/tc-sim-devlet/app.js", "utf8");
  assert.doesNotMatch(app, /session\.setUI\(/);
  assert.match(app, /selectedScreen = button\.dataset\.screen; session\.render\(\)/);
});
test("desk display translations preserve financial numbers and source strings", () => {
  assert.equal(deskEnglish("Çalışma hayatı"), "Working life");
  assert.equal(deskEnglish("KİŞİ DOSYASI"), "Person file");
  assert.equal(deskEnglish("Otomatik kaydedildi. (9 KB)"), "Autosaved. (9 KB)");
  const original = "Enerji -5 · Stres +3 · ₺9.000";
  assert.equal(deskEnglish(original), "Energy -5 · Stress +3 · ₺9.000");
  assert.equal(original, "Enerji -5 · Stres +3 · ₺9.000");
});
