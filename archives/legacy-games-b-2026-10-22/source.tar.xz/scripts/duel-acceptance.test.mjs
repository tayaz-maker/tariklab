import test from "node:test";
import assert from "node:assert/strict";
import { pools } from "./duel-pools.mjs";
import { generateDeck, validateDeck } from "../public/games/duel-core/deckgen.js";
import { createDuel, dispatch } from "../public/games/duel-core/rules.js";
import { legalActions } from "../public/games/duel-core/actions.js";
import { publicView } from "../public/games/duel-core/projection.js";
import { chooseAction } from "../public/games/duel-core/ai.js";
import {
  serialize,
  deserialize,
  saveDuel,
  loadDuel,
  saveKey,
} from "../public/games/duel-core/save.js";
import { primitives } from "../public/games/duel-core/effects.js";
import { labels } from "../public/games/duel-core/labels.js";

for (const [theme, pool] of Object.entries(pools)) {
  test(`${theme}: all 300 source identities, bilingual fields and typed operations resolve`, () => {
    assert.equal(pool.length, 300);
    assert.equal(new Set(pool.map((c) => c.id)).size, 300);
    for (const [i, c] of pool.entries()) {
      assert.equal(Number(c.id.slice(4)), i + 1);
      assert.ok(c.name.tr && c.name.en && c.text.tr && c.text.en);
      assert.ok(Number.isFinite(c.attack) && Number.isFinite(c.defense));
      assert.ok(["unit", "spell", "trap"].includes(c.kind));
      assert.ok(["main", "auxiliary"].includes(c.deckLocation));
      if (c.deckLocation === "auxiliary") assert.equal(c.kind, "unit");
      const inspect = (value, path = c.id) => {
        if (typeof value === "string" && /^(SND|RCN|DRB)-\d{3}$/.test(value))
          assert.ok(
            pool.some((card) => card.id === value),
            `${path}: missing reference ${value}`,
          );
        if (!value || typeof value !== "object") return;
        if (value.op) assert.equal(typeof primitives[value.op], "function", `${path}: ${value.op}`);
        for (const [key, nested] of Object.entries(value)) inspect(nested, `${path}.${key}`);
      };
      inspect({ effects: c.effects, costs: c.costs, triggers: c.triggers, traits: c.traits });
    }
  });
  test(`${theme}: 10,000 seeded decks satisfy the composition and name-copy constraints`, () => {
    const byId = Object.fromEntries(pool.map((c) => [c.id, c]));
    const seen = new Set();
    let mulligans = 0,
      highLevelBricks = 0,
      oldCards = 0,
      newCards = 0;
    for (let seed = 0; seed < 10000; seed++) {
      const deck = generateDeck(pool, seed);
      assert.equal(validateDeck(deck, pool), true, `seed ${seed}`);
      if (deck.mulligan) mulligans++;
      if (!deck.main.slice(0, 5).some((id) => byId[id].kind === "unit" && byId[id].level <= 4))
        highLevelBricks++;
      for (const id of [...deck.main, ...deck.auxiliary]) seen.add(id);
      for (const id of deck.main) {
        if (Number(id.slice(4)) <= 150) oldCards++;
        else newCards++;
      }
    }
    assert.equal(seen.size, 300, "Every old/new main and auxiliary identity is reachable");
    assert.ok(
      oldCards > 100000 && newCards > 100000,
      "Both generations remain materially represented",
    );
    assert.ok(highLevelBricks < 1000, "No excessive tribute-only opening hands");
    console.log(
      JSON.stringify({
        theme,
        decks: 10000,
        oldCards,
        newCards,
        mulligans,
        highLevelBricks,
        seen: seen.size,
      }),
    );
  });
  test(`${theme}: pending decisions, responses and subsequent AI actions survive every reload`, () => {
    let state = createDuel(pool, theme, 28),
      choices = 0;
    for (let step = 0; step < 500 && !state.result; step++) {
      const restored = deserialize(serialize(state), pool, theme);
      assert.equal(restored.ok, true);
      assert.deepEqual(restored.state, state);
      const player = state.choice?.player ?? state.pending?.responding ?? state.active;
      const action = chooseAction(publicView(state, player), legalActions(state, player));
      assert.ok(action);
      const live = dispatch(state, action),
        loaded = dispatch(restored.state, action);
      assert.equal(live.ok, true);
      assert.deepEqual(loaded, live);
      state = live.state;
      if (state.choice) choices++;
    }
    assert.ok(state.result);
    assert.ok(choices > 0);
  });
  test(`${theme}: public projection does not contain opponent hand identities or deck order`, () => {
    const s = createDuel(pool, theme, 42),
      v = publicView(s, 0);
    assert.deepEqual(v.players[1].hand, []);
    assert.equal("deck" in v.players[0], false);
    for (const uid of [...s.players[1].hand, ...s.players[0].deck, ...s.players[1].deck])
      assert.equal(uid in v.cards, false);
    assert.equal("catalog" in v, false);
    assert.equal("rng" in v, false);
  });
  test(`${theme}: quota failure leaves primary intact and corruption recovers only a valid backup`, () => {
    const data = new Map(),
      storage = { getItem: (k) => data.get(k) ?? null, setItem: (k, v) => data.set(k, v) };
    const state = createDuel(pool, theme, 17);
    assert.equal(saveDuel(storage, state).ok, true);
    const original = storage.getItem(saveKey(theme));
    const failed = saveDuel(
      {
        ...storage,
        setItem: () => {
          throw Error("quota");
        },
      },
      state,
    );
    assert.equal(failed.ok, false);
    assert.equal(storage.getItem(saveKey(theme)), original);
    assert.equal(saveDuel(storage, state).ok, true);
    storage.setItem(saveKey(theme), "{broken");
    const recovered = loadDuel(storage, pool, theme);
    assert.equal(recovered.ok, true);
    assert.equal(recovered.recovered, true);
    assert.deepEqual(recovered.state, state);
  });
}
test("TR and EN UI keys are complete and symmetrical", () => {
  assert.deepEqual(Object.keys(labels.tr).sort(), Object.keys(labels.en).sort());
  for (const dict of Object.values(labels))
    assert.ok(Object.values(dict).every((v) => typeof v === "string" && v.length));
});

test("AI passes a self-destructive mutual trade against an empty public field and spots lethal effects", () => {
  const clash = pools["gett-oh"].find((c) => c.id === "RCN-139");
  const view = {
    viewer: 0,
    players: [
      { points: 8000, units: ["own"] },
      { points: 400, units: [null, null, null, null, null] },
    ],
    cards: { clash },
  };
  const pass = { type: "pass", player: 0 },
    respond = { type: "respond", player: 0, card: "clash" };
  assert.deepEqual(chooseAction(view, [pass, respond]), pass);
  const lethal = { type: "activate", player: 0, card: "damage" };
  view.cards.damage = { effects: [{ op: "points", opponent: true, amount: -500 }] };
  assert.deepEqual(chooseAction(view, [pass, lethal]), lethal);
});
